
# include "iGraphics.h"
#include <string>
#define screenwidth 900
#define screenheight 400
#define NUMBEROFDRAGON 5
#define JUMPLIMIT 50
char logo[13] = { "pic\\3.bmp" };
char menu[13] = { "pic\\logo.bmp" };

int jacks = 0;
int gamestate = 0;
int position[2];
char under[2][30] = { "pic\\unde1.bmp", "pic\\under.bmp" };
int slice = 2;
int width = 900 / 2;
int mposx, mposy;

bool pause = true;

bool musicon = true;
int x = 0;
int y = 0;
int dx = 10;
int dy = 10;
int r = rand() % 255;
int g = rand() % 255;
int b = rand() % 155;
void change();
/*
function iDraw() is called again and again by the system.
*/

//jack*******
char jack[8][30] = { "pic\\pm.bmp", "pic\\pm.bmp" };
char jackshoot[2][20] = { "pic\\pm.bmp", "pic\\spm.bmp" };
struct s6{
	int jx;
	int jy;
	int jindex;
}s6;
int jackcordinatex = 0;
int jackdx = 100;
int jackdy = 300;
int jackcordinatey = 60;
int jackindex = 0;
bool shoot = false;
bool shootup = false;
bool  shootdown = false;

int jackcordinateshoot = 0;
bool shootposition = true;
int shootcounter = 0;
int score = 0;
char scoretext[50];

//dragon********
int i = 0;

int m = 0;


char dragonup[4][50] = { "pic\\rio2.bmp", "pic\\rio2.bmp", "pic\\rio2.bmp", "pic\\rio2.bmp" };
struct s2{
	int dragonupx;
	int dragonupy;
	int dragondx = 20;
	int dragondy = 100;
	int dragonupindex;
}s2;
char bullet[6][50] = { "pic\\arrow.bmp", "pic\\arrow.bmp", "pic\\arrow.bmp", "pic\\arrow.bmp", "pic\\arrow.bmp", "pic\\arrow.bmp" };
struct s{
	int dragonx = 200;
	int dragony = 900;

	int dragonindex;
	bool dragonsdragonmidow;
}s1;
char arrow[2][50] = { "pic\\arrow.bmp", "pic\\arrow.bmp" };
struct a{
	int ax;
	int ay;
	int aindex;
}a;
char h[4][50] = { "pic\\rio.bmp", "pic\\rio.bmp", "pic\\rio.bmp", "pic\\rio.bmp" };
struct s3{
	int dragonupx;
	int dragonupy;
	int dragondx = 20;
	int dragondy = 100;
	int dragonupindex;
}s3;
char bomb[4][50] = { "pic\\bomb1.bmp", "pic\\bomb1.bmp", "pic\\bomb1.bmp", "pic\\bomb1.bmp" };

int bombx;
int bomby;
int bombdx = 20;
int bombdy = 100;
int bombindex;

char bomb1[4][50] = { "pic\\bomb3.bmp", "pic\\bomb3.bmp", "pic\\bomb3.bmp", "pic\\bomb3.bmp" };

int bomb1x;
int bomb1y;
int bomb1dx = 20;
int bomb1dy = 100;
int bomb1index;


void collisoncheck();




void iDraw()
{


	//place your drawing codes here
	iClear();
	if (gamestate == 0){
		iShowBMP(0, 0, logo);
	}

	if (gamestate == 1){
		iShowBMP(0, 0, "pic\\Menu1.bmp");
		//iShowBMP2(368, 280, "pic\\jack.bmp", 0);
		iShowBMP2(10, 191, "pic\\play.bmp", 0);
		iShowBMP2(10, 140, "pic\\highscore.bmp", 0);
		iShowBMP2(10, 91, "pic\\st.bmp", 0);
		iShowBMP2(10, 45, "pic\\instructions.bmp", 0);
	}


	if (gamestate == 2){

		iShowBMP2(0, 0, "pic\\back.bmp", 0);
		//iShowBMP2(0, 0,under[1],0);
		//iShowBMP2(s1.dragonx, s1.dragony, bullet[s1.dragonindex], 0);
		iShowBMP2(s2.dragonupx, s2.dragonupy, dragonup[s2.dragonupindex], 0);
		iShowBMP2(s3.dragonupx, s3.dragonupy, h[s3.dragonupindex], 0);
		iShowBMP2(bombx, bomby, bomb[bombindex], 0);
		iShowBMP2(bomb1x, bomb1y, bomb1[bomb1index], 0);

		if (shoot){
			a.ay = jackcordinatey + 50;
			a.ax += 10;
			if (a.ax > screenwidth){
				a.ax = jackcordinatex + 30;
				shoot = false;

				a.aindex++;
				if (a.aindex >= 1){
					a.aindex = 0;
				}
			}
			iShowBMP2(a.ax, a.ay, arrow[a.aindex], 0);

		}




		//if (shoot){
		if (shoot){
			iShowBMP2(jackcordinatex, jackcordinatey + jackcordinateshoot, jackshoot[1], 0);
			//shoot = false;
		}
		//else{
		//iShowBMP2(jackcordinatex, jackcordinatey + jackcordinateshoot, jackshoot[0], 0);
		//}
		//}
		else {
			if (!shootposition){
				iShowBMP2(jackcordinatex, jackcordinatey, jack[jackindex], 0);

				if (shootcounter >= 2){
					shootcounter = 0;
					jackindex = 0;
					shootposition = true;
				}
			}
			else{
				iShowBMP2(jackcordinatex, jackcordinatey, jack[1], 0);
			}
		}

		sprintf_s(scoretext, "SCORE: %d", score);
		iText(screenwidth - 200, iScreenHeight - 50, scoretext, GLUT_BITMAP_TIMES_ROMAN_24);
		iSetColor(250, 45, 54);
		//if (score >= 100){
		//gamestate = 7;

		//}
		if ((jackcordinatex + jackdx>bombx && jackcordinatex<bombx + bombdx) && (jackcordinatey + jackdy>bomby && jackcordinatey< bomby + bombdy)){
			gamestate = 7;





		}
		if ((jackcordinatex + jackdx>bomb1x && jackcordinatex<bomb1x + bombdx) && (jackcordinatey + jackdy>bomb1y && jackcordinatey< bomb1y + bomb1dy)){
			gamestate = 7;





		}
	}
	if (gamestate == 4){
		iShowBMP(0, 0, "pic\\score1.bmp");
	}

	if (gamestate == 5){
		iShowBMP(0, 0, "pic\\sound.bmp");
	}
	if (gamestate == 6){
		iShowBMP(0, 0, "pic\\ip.bmp");
	}
	if (gamestate == 7){
		iShowBMP(0, 0, "pic\\game.bmp");
		//iShowBMP2(368, 280, "pic\\jack.bmp", 0);
		iShowBMP2(381, 68, "pic\\Exit.bmp", 0);
		iShowBMP2(378, 20, "pic\\replay.bmp", 0);
		//iShowBMP2(368, 110, "pic\\next.bmp", 255);
	}
	if (gamestate == 2 && pause == false){
		iShowBMP2(805, 20, "pic\\home.bmp", 0);
	}


}

/*
function iMouseMove() is called when the user presses and drags the mouse.
(mx, my) is the position where the mouse pointer is.
*/
void iMouseMove(int mx, int my)
{
	//place your codes here
}

/*
function iMouse() is called when the user presses/releases the mouse.
(mx, my) is the position where the mouse pointer is.
*/
void iMouse(int button, int state, int mx, int my)
{
	printf("%d %d\n", mx, my);

	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		if (gamestate == 0){
			if (mx >= 0 && mx <= 900 && my >= 0 && my <= 400){
				gamestate = 1;
			}
		}
		if (gamestate == 1){
			if (mx >= 10 && mx <= 155 && my >= 195 && my <= 238){
				gamestate = 2;
			}
		}
		if (gamestate == 1){
			if (mx >= 10 && mx <= 155 && my >= 147 && my <= 185){
				gamestate = 4;
			}
		}
		if (gamestate == 1){
			if (mx >= 10 && mx <= 155 && my >= 94 && my <= 134){
				gamestate = 5;
			}
		}
		if (gamestate == 1){
			if (mx >= 10 && mx <= 155 && my >= 50 && my <= 89){
				gamestate = 6;
			}
		}


		if (gamestate == 7){
			if (mx >= 381 && mx <= 524 && my >= 73 && my <= 113){
				gamestate = 0;
			}
		}
		if (gamestate == 7){
			if (mx >= 378 && mx <= 521 && my >= 28 && my <= 65){
				score = 0;
				gamestate = 2;
			}
		}
		if (gamestate == 2){
			if (mx >= 815 && mx <= 882 && my >= 38 && my <= 102){

				gamestate = 1;
			}
		}


	}
	if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		//place your codes here
	}
}
/*iPassiveMouseMove is called to detect and use
the mouse point without pressing any button */

void iPassiveMouseMove(int mx, int my)
{
	//place your code here

	mposx = mx;
	mposy = my;
	if (mx == 2){}        /*Something to do with mx*/
	else if (my == 2){}   /*Something to do with my*/

}

/*
function iKeyboard() is called whenever the user hits a key in keyboard.
key- holds the ASCII value of the key pressed.
*/
void iKeyboard(unsigned char key)
{
	if (key == 'q')
	{
		//do something with 'q'
	}
	if (key == ' '){
		if (!shoot){
			shoot = true;
			shootup = true;

		}
		else{
			shoot = false;
			shootup = false;
		}
	}
	if (key == 'f') //for missile
	{
		s2.dragonupx = s1.dragonx;
		s2.dragonupy = s1.dragony;
		m = 1;

	}
	if (key == 'm') //for music control
	{
		if (musicon == true)
		{
			musicon = false;
			PlaySound(0, 0, 0);
		}
		else
		{
			musicon = true;
			PlaySound("music\\stranger.wav", NULL, SND_LOOP | SND_ASYNC);
		}
	}

	if (key == 'p') //for music control
	{
		if (pause == true)
			pause = false;
		else
			pause = true;
	}
	//place your codes for other keys here
}

/*
function iSpecialKeyboard() is called whenver user hits special keys like-
function keys, home, end, pg up, pg down, arraows etc. you have to use
appropriate constants to detect them. A list is:
GLUT_KEY_F1, GLUT_KEY_F2, GLUT_KEY_F3, GLUT_KEY_F4, GLUT_KEY_F5, GLUT_KEY_F6,
GLUT_KEY_F7, GLUT_KEY_F8, GLUT_KEY_F9, GLUT_KEY_F10, GLUT_KEY_F11, GLUT_KEY_F12,
GLUT_KEY_LEFT, GLUT_KEY_UP, GLUT_KEY_RIGHT, GLUT_KEY_DOWN, GLUT_KEY_PAGE UP,
GLUT_KEY_PAGE DOWN, GLUT_KEY_HOME, GLUT_KEY_END, GLUT_KEY_INSERT
*/
void iSpecialKeyboard(unsigned char key)
{

	if (key == GLUT_KEY_UP && pause == true)
	{
		jackcordinatey += 10;
		void collisonCheck();
	}
	else if (key == GLUT_KEY_DOWN  && pause == true){

		jackcordinatey -= 10;
		void collisonCheck();
	}
	else if (key == GLUT_KEY_LEFT  && pause == true){
		jackcordinatex -= 10;
		void collisonCheck();

		jackindex--;
		if (jackindex <0){
			jackindex = 1;
			shootposition = false;
		}
	}
	else if (key == GLUT_KEY_RIGHT  && pause == true){
		jackcordinatex += 10;
		void collisonCheck();
		jackindex++;
		if (jackindex >= 2){
		}

		jackindex = 1;
	}

	else if (key == GLUT_KEY_END){

		if (gamestate == 2){
			gamestate = 1;
		}



	}
	shootposition = false;
	//place your codes for other keys here
}

void arrmove(){
	//if (i == 1){
	//s2.dragonupy += 10;
	//}




}

void collisonCheck(){


	/*if ((s2.dragonupx >=s3.dragonupx && s2.dragonupx<s3.dragonupx +100) && (s2.dragonupy+113 >s3.dragonupy && s2.dragonupy+113< s3.dragonupy + 100)){
	m = 0;
	s3.dragonupx = 1500;
	//s3.dragonupy = 1500;
	}

	else{

	}*/

}

void change(){
	if (shoot){
		if (jackcordinateshoot >= JUMPLIMIT){
			shootup = false;
		}
	}
	else{

		if (jackcordinateshoot < 0){
			shoot = false;
			jackcordinateshoot = 0;
		}
	}



	s1.dragonx += 10;
	if (s1.dragonx <= 0 && pause == true){
		s1.dragonx = screenheight + rand() % 200;

		s1.dragonindex++;
		if (s1.dragonindex >= 100 && pause == true){
			s1.dragonindex = 0;

		}
	}

	if (pause == true)
	{
		s2.dragonupx -= 10;
	}
	if (s2.dragonupx <= 0 && pause == true){
		s2.dragonupx = screenwidth + rand() % 200;

		s2.dragonupindex++;
		if (s2.dragonupindex >= 4 && pause == true){
			s2.dragonupindex = 0;

		}
	}
	//collision of middle enemy
	else if (a.ax + 130 >= s2.dragonupx && (a.ay >= s2.dragonupy  &&  a.ay <= s2.dragonupy + 108)){
		s2.dragonupx = screenwidth + rand() % 200;
		score += 20;
	}
	if (pause == true)
	{
		s3.dragonupx -= 10;
	}
	if (s3.dragonupx <= 0 && pause == true){
		s3.dragonupx = screenwidth + rand() % 200;

		s3.dragonupindex++;
		if (s3.dragonupindex >= 4 && pause == true){
			s3.dragonupindex = 0;

		}
	}
	//collision of upper enemy
	else if (a.ax + 130 >= s3.dragonupx && (a.ay >= s3.dragonupy  &&  a.ay <= s3.dragonupy + 108)){
		s3.dragonupx = screenwidth + rand() % 200;
		score += 20;
	}

	s6.jx -= 10;
	if (s6.jx >= 0){
		s6.jx = screenwidth + rand() % 200;

		s6.jindex++;
		if (s6.jindex >= 1){
			s6.jindex = 0;

		}
	}

	if (pause == true){

		bombx -= 10;
	}
	if (bombx <= 0 && pause == true){
		bombx = screenwidth + rand() % 10;

		bombindex++;
		if (bombindex >= 4 && pause == true){
			bombindex = 0;

		}
	}
	if (pause == true){

		bomb1x -= 10;
	}
	if (bomb1x <= 0 && pause == true){
		bomb1x = screenwidth + rand() % 150;

		bomb1index++;
		if (bomb1index >= 4 && pause == true){
			bomb1index = 0;

		}
	}


}

void setEnemyvariables(){
	s1.dragonx = 20 + rand() % 90;
	s1.dragony = 50 + rand() % 10;
	s1.dragonindex = rand() % 8;
	s2.dragonupx = screenwidth + rand() % 200;
	s2.dragonupy = 150 + rand() % 50;
	s2.dragonupindex = rand() % 3;
	a.ax = jackcordinatex - 300;
	a.ay = jackcordinatey - 300;
	//a.aindex = rand() % 6;

	s3.dragonupx = screenwidth + rand() % 800;
	s3.dragonupy = 250 + rand() % 300;
	s3.dragonupindex = rand() % 4;
	s6.jx = screenwidth + rand() % 140;
	s6.jy = 150 + rand() % 20;
	s6.jindex = rand() % 2;
	bombx = screenwidth + rand() % 10;
	bomby = rand() % 40;
	bombindex = rand() % 4;
	bomb1x = screenwidth + rand() % 700;
	bomb1y = rand() % 393;
	bomb1index = rand() % 2;

}
void positionfunction(){
	int i, j;
	for (i = 0, j = 0; i < slice; i++)
	{
		position[i] = j;
		j += width;
	}
}

//
int main()
{
	positionfunction();
	setEnemyvariables();
	//iSetTimer(25, arrmove);
	iSetTimer(65, change);
	iSetTimer(1000, collisonCheck);
	if (musicon){
		PlaySound("music\\stranger.wav", NULL, SND_LOOP | SND_ASYNC);
	}
	//place your own initialization codes here.
	iInitialize(screenwidth, screenheight, "Shooting Rio");
	return 0;
}
